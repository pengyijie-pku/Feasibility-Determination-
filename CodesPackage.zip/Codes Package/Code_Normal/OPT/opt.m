n=10;
mu0=0;
sigma0=1;
sigma=2;
gamma=0;
n0=10;
q=zeros(1000,1);
TN=400;

alpha=1-1/TN;
epsilon=0.01;
delta=0.01;
nint=50;

mu=zeros(n,1);
xbar=zeros(n,1);
sbar=zeros(n,1);
cunt=zeros(n,1);
beta=zeros(n,1);
l=zeros(n,1);
g=zeros(n,1);

for i=1:1000
    i
   for j=1:n
       mu(j)=normrnd(mu0,sigma0);
   end
   In=mu<gamma;
   for j=1:n
       x0(j)={normrnd(mu(j),sigma,n0,1)};
       xbar(j)=mean(x0{j});
       sbar(j)=std(x0{j});
       l(j)=n0;
       cunt(j)=floor(l(j)/nint);
   end
   sl=sum(l);
   for j=1:n
       beta(j)=l(j)/sbar(j)^2;
       mu_up(j)=gamma+norminv(1-epsilon)/sqrt(beta(j));
       mu_up(j)=round(mu_up(j)*100)/100;
       mu_low(j)=gamma*2-mu_up(j);
       state(j)={[mu_low(j):delta:mu_up(j)]'};
       num_state=length(state{j});
       nmu_up(j)=gamma+norminv(1-epsilon)/sqrt(beta(j)+1/sbar(j)^2);
       nmu_up(j)=round(nmu_up(j)*100)/100;
       nmu_low(j)=gamma*2-nmu_up(j);
       nstate(j)={linspace(nmu_low(j),nmu_up(j),num_state)'};
       %nstate(j)={[nmu_low(j):delta:nmu_up(j)]'};
       p(j)={transit(state{j},nstate{j},beta(j),l(j))};
       r(j)={optreward(state{j},nstate{j},beta(j),l(j),p{j},gamma)};
       git(j)={gittins(alpha,r{j},p{j})};
       if xbar(j)<mu_low(j) || xbar(j)>mu_up(j)
           g(j)=0;
       else
           [~, pos]=min(abs(state{j}-xbar(j)));
           g(j)=git{j}(pos);
       end
   end
   for j=n*n0+1:TN
       [~,k]=max(g);
       l(k)=l(k)+1;
       y=normrnd(mu(k),sigma);
       x0(k)={[x0{k};y]};
       xbar(k)=mean(x0{k});
       sbar(k)=std(x0{k});
       if cunt(k)==floor(l(k)/nint)
            if xbar(k)<mu_low(k) || xbar(k)>mu_up(k)
            g(k)=0;
            else
            [~, pos]=min(abs(state{k}-xbar(k)));
            g(k)=git{k}(pos);
            end
       else
           cunt(k)=cunt(k)+1;
           beta(k)=l(k)/sbar(k)^2;
           mu_up(k)=gamma+norminv(1-epsilon)/sqrt(beta(k));
           mu_up(k)=round(mu_up(k)*100)/100;
           mu_low(k)=gamma*2-mu_up(k);
           state(k)={[mu_low(k):delta:mu_up(k)]'};
           num_state=length(state{k});
           nmu_up(k)=gamma+norminv(1-epsilon)/sqrt(beta(k)+1/sbar(k)^2);
           nmu_up(k)=round(nmu_up(k)*100)/100;
           nmu_low(k)=gamma*2-nmu_up(k);
           nstate(k)={linspace(nmu_low(k),nmu_up(k),num_state)'};
           p(k)={transit(state{k},nstate{k},beta(k),l(k))};
           r(k)={optreward(state{k},nstate{k},beta(k),l(k),p{k},gamma)};
           git(k)={gittins(alpha,r{k},p{k})};
           if xbar(k)<mu_low(k) || xbar(k)>mu_up(k)
           g(k)=0;
           else
           [~, pos]=min(abs(state{k}-xbar(k)));
           g(k)=git{k}(pos);
           end
       end
   end
   Ein=xbar<gamma;
   dif=Ein-In;
   num=find(dif==0);
   q(i)=length(num);
end
per=mean(q)/n;
       