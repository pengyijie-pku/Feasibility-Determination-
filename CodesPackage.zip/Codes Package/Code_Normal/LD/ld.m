function correct_number=ld(TN,mu,sigma,gamma,n0)
n=length(mu);
xbar=zeros(n,1);
sbar=zeros(n,1);
e=zeros(n,1);
l=zeros(n,1);

In=mu<gamma;
In=In';
for j=1:n
    x0(j)={normrnd(mu(j),sigma,n0,1)};
    xbar(j)=mean(x0{j});
    sbar(j)=std(x0{j});
    l(j)=n0;
end
   sl=sum(l);
   e=ald1(xbar,sbar,gamma)*(sl+1)-l;
for j=n*n0+1:TN
   [ma,k]=max(e);
   l(k)=l(k)+1;
   sl=sl+1;
   y=normrnd(mu(k),sigma);
   x0(k)={[x0{k};y]};
   xbar(k)=mean(x0{k});
   sbar(k)=std(x0{k});
   e=ald1(xbar,sbar,gamma)*(sl+1)-l;
end
Ein=xbar<gamma;
dif=Ein-In;
num=find(dif==0);
%correct_number=length(num);
if length(num)==n
    correct_number=1;
else
    correct_number=0;
end