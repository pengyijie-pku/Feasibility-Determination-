function alpha=ald1(mu,sigma,gamma)
m=length(mu);
alpha=zeros(m,1);
I=zeros(m,1);
r=0;
for i=1:m
    I(i)=(mu(i)-gamma)^2/sigma(i)^2;
    r=r+1/I(i);
end
for i=1:m
    alpha(i)=(1/I(i))/r;
end


   
    