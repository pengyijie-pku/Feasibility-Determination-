function alpha=fld1(mu,sigma,gamma,sl)
m=length(mu);
alpha=zeros(m,1);
I=zeros(m,1);
asl=sl+1;
r=0;
s=0;
p=zeros(m,1);
c=zeros(m,1);
for i=1:m
    I(i)=(mu(i)-gamma)^2/sigma(i)^2;
    r=r+1/I(i);
    s=s+log(I(i))/I(i);
end
for i=1:m
    p(i)=(1/I(i))/r;
    c(i)=log(I(i))*r-s;
end
minc=min(c);
d=max(0,-minc/0.62-0.5*r-asl);
for i=1:m
alpha(i)=p(i)*(1+c(i)/(asl+d+0.5*r));
end

   
    