mc=2000;  
res=[1 3 2 7;1 3 2 8;1 4 2 5;1 3 3 6;1 3 3 7];
gamma=2;
In=[0 1 0 0 1]';

n0=4;
TN=40;
Ein=zeros(5,1);
rep=400
q=zeros(rep,1);


r=zeros(5,1);
l=zeros(5,1);
xbar=zeros(5,1);
sbar=zeros(5,1);
Ein=zeros(5,1);

for i=1:rep
    i
    for j=1:5
        x0(j)={edhc(res(j,1),res(j,2),res(j,3),res(j,4),n0)};
        xbar(j)=mean(x0{j});
        sbar(j)=std(x0{j});
        l(j)=n0;
    end
   for j=1:5
       r(j)=reward2(xbar(j), sbar(j), l(j), mc, gamma);
   end
   for j=5*n0+1:TN
       [~, k]=max(r);
       l(k)=l(k)+1;
       y=edhc(res(k,1),res(k,2),res(k,3),res(k,4),1);
       x0(k)={[x0{k},y]};
       xbar(k)=mean(x0{k});
       sbar(k)=std(x0{k});
       r(k)=reward2(xbar(k),sbar(k),l(k),mc,gamma);
   end
   Ein=xbar<gamma;
   dif=Ein-In;
   num=find(dif==0);
   q(i)=length(num);
end
per=mean(q);
sol=std(q);