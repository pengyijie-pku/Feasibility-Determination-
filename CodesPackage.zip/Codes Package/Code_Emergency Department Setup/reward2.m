function x = reward2(mu, sigma, l, mc, gamma)
h=normcdf(abs(mu-gamma)*sqrt(l)/sigma);
s=-2+2*rand(mc,1);
r=zeros(mc,1);
for i=1:mc
    gap=abs(mu+sigma*sqrt(1/l-1/(l+1))*s(i)-gamma);
    r(i)=normcdf(gap*sqrt(l+1)/sigma)*exp(-s(i)^2/2);
end
x=mean(r)/sqrt(2*pi)-h;