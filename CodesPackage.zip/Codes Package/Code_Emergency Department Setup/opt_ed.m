res=[1 3 2 7;1 3 2 8;1 4 2 5;1 3 3 6;1 3 3 7];
gamma=2;
In=[0 1 0 0 1]';

n0=4;
TN=40;
Ein=zeros(5,1);
rep=400;
q=zeros(rep,1);

alpha=1-1/TN;
epsilon=0.01;
delta=0.01;
nint=50;

xbar=zeros(5,1);
sbar=zeros(5,1);
cunt=zeros(5,1);
beta=zeros(5,1);
l=zeros(5,1);
g=zeros(5,1);

for i=1:rep
    i
   for j=1:5
        x0(j)={edhc(res(j,1),res(j,2),res(j,3),res(j,4),n0)};
        xbar(j)=mean(x0{j});
        sbar(j)=std(x0{j});
        l(j)=n0;
        cunt(j)=floor(l(j)/nint);
   end
   sl=sum(l);
   for j=1:5
       beta(j)=l(j)/sbar(j)^2;
       mu_up(j)=gamma+norminv(1-epsilon)/sqrt(beta(j));
       mu_up(j)=round(mu_up(j)*100)/100;
       mu_low(j)=gamma*2-mu_up(j);
       state(j)={[mu_low(j):delta:mu_up(j)]'};
       num_state=length(state{j});
       nmu_up(j)=gamma+norminv(1-epsilon)/sqrt(beta(j)+1/sbar(j)^2);
       nmu_up(j)=round(nmu_up(j)*100)/100;
       nmu_low(j)=gamma*2-nmu_up(j);
       nstate(j)={linspace(nmu_low(j),nmu_up(j),num_state)'};
       %nstate(j)={[nmu_low(j):delta:nmu_up(j)]'};
       p(j)={transit(state{j},nstate{j},beta(j),l(j))};
       r(j)={optreward(state{j},nstate{j},beta(j),l(j),p{j},gamma)};
       git(j)={gittins(alpha,r{j},p{j})};
       if xbar(j)<mu_low(j) || xbar(j)>mu_up(j)
           g(j)=0;
       else
           [~, pos]=min(abs(state{j}-xbar(j)));
           g(j)=git{j}(pos);
       end
   end
   for j=5*n0+1:TN
       [~,k]=max(g);
       l(k)=l(k)+1;
       y=edhc(res(k,1),res(k,2),res(k,3),res(k,4),1);
       x0(k)={[x0{k},y]};
       xbar(k)=mean(x0{k});
       sbar(k)=std(x0{k});
       if cunt(k)==floor(l(k)/nint)
            if xbar(k)<mu_low(k) || xbar(k)>mu_up(k)
            g(k)=0;
            else
            [~, pos]=min(abs(state{k}-xbar(k)));
            g(k)=git{k}(pos);
            end
       else
           cunt(k)=cunt(k)+1;
           beta(k)=l(k)/sbar(k)^2;
           mu_up(k)=gamma+norminv(1-epsilon)/sqrt(beta(k));
           mu_up(k)=round(mu_up(k)*100)/100;
           mu_low(k)=gamma*2-mu_up(k);
           state(k)={[mu_low(k):delta:mu_up(k)]'};
           num_state=length(state{k});
           nmu_up(k)=gamma+norminv(1-epsilon)/sqrt(beta(k)+1/sbar(k)^2);
           nmu_up(k)=round(nmu_up(k)*100)/100;
           nmu_low(k)=gamma*2-nmu_up(k);
           nstate(k)={linspace(nmu_low(k),nmu_up(k),num_state)'};
           p(k)={transit(state{k},nstate{k},beta(k),l(k))};
           r(k)={optreward(state{k},nstate{k},beta(k),l(k),p{k},gamma)};
           git(k)={gittins(alpha,r{k},p{k})};
           if xbar(k)<mu_low(k) || xbar(k)>mu_up(k)
           g(k)=0;
           else
           [~, pos]=min(abs(state{k}-xbar(k)));
           g(k)=git{k}(pos);
           end
       end
   end
   Ein=xbar<gamma;
   dif=Ein-In;
   num=find(dif==0);
   q(i)=length(num);
end
per=mean(q);
sol=std(q);
       