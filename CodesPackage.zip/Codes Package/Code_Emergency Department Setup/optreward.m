function r=optreward(state, nstate, beta, l, p, gamma)
n=length(state);
m=length(nstate);
r=zeros(n,1);
a=zeros(n,1);
b=zeros(m,1);
c=zeros(n,1);
for i=1:n
    a(i)=normcdf(abs(state(i)-gamma)*sqrt(beta));
end
for i=1:m
    b(i)=normcdf(abs(nstate(i)-gamma)*sqrt(beta*(l+1)/l));
end
for i=1:n
    for j=1:m
        c(i)=c(i)+p(i,j)*b(j);
    end
    r(i)=c(i)-a(i);
end