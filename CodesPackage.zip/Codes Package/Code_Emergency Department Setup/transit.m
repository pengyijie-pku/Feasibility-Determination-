function p=transit(state, nstate, beta, l)
n=length(state);
m=length(nstate);
stilda=sqrt(1/(beta*(l+1)));
q=zeros(n,m);
p=zeros(n,m);
a=zeros(n,1);
for i=1:n
    for j=1:m
        q(i,j)=normpdf((nstate(j)-state(i))/stilda);
        a(i)=a(i)+q(i,j);
    end
end
for i=1:n
    for j=1:m
        p(i,j)=q(i,j)/a(i);
    end
end