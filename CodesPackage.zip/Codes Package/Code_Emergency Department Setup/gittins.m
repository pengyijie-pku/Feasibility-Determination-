function x=gittins(beta, r, p)
% calculate gittins index
% beta is discount coefficient
% r is reward, note r should be n*1 dimension
% p is transition matrix
n = length(r);
c = zeros(n, 1);
x = zeros(n, 1);
[ma, ind] = max(r);
x(ind) = ma;
c(ind) = 1;
q=zeros(n, n);
for i=2:n
   for j=1:n
       if c(j)==0
           q(:,j)=0;
       else
           q(:,j)=p(:,j);
       end
   end   
   d= mldivide(eye(n)-beta*q , r);
   for j=1:n
       if c(j)==1
           d(j)=0;
       end
   end
   b= mldivide(eye(n)-beta*q, ones(n,1));
   [ma ind] = max(d./b);
   x(ind) = ma;
   c(ind) = 1;
end
           
           
