tic;
tstart=tic;
res=[1 3 2 7;1 3 2 8;1 4 2 5;1 3 3 6;1 3 3 7];
n=8;
threshold=2;
In=[0 1 0 0 1]';
Ein=zeros(5,1);
rep=500;
q=zeros(rep,1);
mea=zeros(5,1);
for i=1:rep
    i
    for j=1:5
        mea(j)=mean(edhc(res(j,1),res(j,2),res(j,3),res(j,4),n));
        if mea(j)<threshold
            Ein(j)=1;
        else Ein(j)=0;
        end
    end
    dif=In-Ein;
    num=find(dif==0);
    q(i)=length(num);
end
per=mean(q);
sol_std=std(q);
telapsed=toc(tstart);