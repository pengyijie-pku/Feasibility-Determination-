res=[1 3 2 7;1 3 2 8;1 4 2 5;1 3 3 6;1 3 3 7];
gamma=2;
In=[0 1 0 0 1]';

n0=4;
TN=40;
Ein=zeros(5,1);
rep=400;
%rep=1;

xbar=zeros(5,1);
sbar=zeros(5,1);
e=zeros(5,1);
l=zeros(5,1);
q=zeros(rep,1);
%qq=0;

for i=1:rep
    i
   for j=1:5
        x0(j)={edhc(res(j,1),res(j,2),res(j,3),res(j,4),n0)};
        xbar(j)=mean(x0{j});
        sbar(j)=std(x0{j});
        l(j)=n0;
   end
   sl=sum(l);
   e=fld1(xbar,sbar,gamma,sl)*(sl+1)-l;
   for j=5*n0+1:TN
       [~,k]=max(e);
       l(k)=l(k)+1;
       sl=sl+1;
       y=edhc(res(k,1),res(k,2),res(k,3),res(k,4),1);
       x0(k)={[x0{k},y]};
       xbar(k)=mean(x0{k});
       sbar(k)=std(x0{k});
       e=fld1(xbar,sbar,gamma,sl)*(sl+1)-l;
   end
   Ein=xbar<gamma;
   dif=Ein-In;
   num=find(dif==0);
   q(i)=length(num);
   %if(In==Ein)
       %qq=qq+1;
   %end
end
%per=qq/10000;
per=mean(q);
sol=std(q);
        
        