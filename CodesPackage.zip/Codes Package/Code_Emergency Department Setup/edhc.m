function measure=edhc(num_recep,num_doc,num_tech,num_nurse,n)
total_hours=2520;     %total simulation time
upper_limit=2496;     %truncation upper limit;
ambu_arr_mean=0.5;    %ambulance arrival mean
norm_arr_mean=[1/5.25 1/3.8 1/3 1/4.8 1/ 7 1/8.25 1/9 1/7.75 1/7.75 1/8 1/6.5 1/3.25];   %walk in arrival mean
recep_mean=7.5/60;     %reception mean
%num_recep=1;           %number of receptionist
%num_doc=4;             %number of doctors
exam_mean=0.25;        %examination mean
reexam_mean=9/60;      %reexamination mean
%num_tech=3;            %number of technicians
lab_a=1/6;
lab_b=2/6;
lab_c=3/6;
%num_nurse=5;           %number of emergency room nurses;
emer_mean=1.5;         %emergency mean


%we now generate the arrivals of examination room

%first generate ambulance arrivals
if n==0 measure=[];
else
for l=1:n
    clear ambu_arr norm_walkin norm_arr lab_leav emer_arr fwtime;
ambu_num=0;
ambu_arr(1)=exprnd(ambu_arr_mean);
while ambu_arr(ambu_num+1)<total_hours
    ambu_num=ambu_num+1;
    ambu_arr(ambu_num+1)=ambu_arr(ambu_num)+exprnd(ambu_arr_mean);
end
ambu_arr(ambu_num+1)=[];
ambu_wtime=zeros(1,ambu_num);

%generate walk-in arrivals
norm_num=0;
norm_walkin(1)=exprnd(norm_arr_mean(1));
while norm_walkin(norm_num+1)<total_hours
    norm_num=norm_num+1;
    rate_ind=floor(0.5*mod(norm_walkin(norm_num),24))+1;
    norm_walkin(norm_num+1)=norm_walkin(norm_num)+exprnd(norm_arr_mean(rate_ind));
end

%simulate reception process
recep_times=zeros(num_recep,1);     %the times when the receptionists are available
norm_wtime=zeros(1,norm_num);
for k=1:norm_num
    [recep_serve,recep_ind]=min(recep_times);
    if(recep_serve<=norm_walkin(k))
        norm_arr(k)=norm_walkin(k)+exprnd(recep_mean);
        recep_times(recep_ind)=norm_arr(k);
    else norm_arr(k)=recep_serve+exprnd(recep_mean);
        recep_times(recep_ind)=norm_arr(k);
        norm_wtime(k)=recep_serve-norm_walkin(k);
    end
end

%combine ambulance arrival and walkin arrival
arr=[ambu_arr norm_arr];
wtime=[ambu_wtime norm_wtime];
total_arr=length(arr);
if total_arr~=length(wtime)
    error('arrival wrong');
end
[arr,arr_ind]=sort(arr,'ascend');
wtime=wtime(arr_ind);

%simulate exmination & lab test processes
doc_times=zeros(num_doc,1);
tech_times=zeros(num_tech,1);
k=1;
ar_ind=1:total_arr;
reexam_ind=zeros(total_arr,1);
exam_leav=zeros(1,total_arr);
doc_leav=zeros(1,total_arr);
while k<=total_arr
    [doc_serve,doc_ind]=min(doc_times);
    if reexam_ind(ar_ind(k))==0
        if doc_serve<=arr(k)
            exam_leav(ar_ind(k))=arr(k)+exprnd(exam_mean);
        else exam_leav(ar_ind(k))=doc_serve+exprnd(exam_mean);
            wtime(ar_ind(k))=wtime(ar_ind(k))+doc_serve-arr(k);
        end
        doc_times(doc_ind)=exam_leav(ar_ind(k));
        route_1=binornd(1,0.5);
        if route_1==0
            [tech_serve,tech_ind]=min(tech_times);
            if tech_serve<=exam_leav(ar_ind(k))
                lab_leav(ar_ind(k))=exam_leav(ar_ind(k))+trianrnd(lab_a,lab_b,lab_c,1);
            else lab_leav(ar_ind(k))=tech_serve+trianrnd(lab_a,lab_b,lab_c,1);
                wtime(ar_ind(k))=wtime(ar_ind(k))+tech_serve-exam_leav(ar_ind(k));
            end
            tech_times(tech_ind)=lab_leav(ar_ind(k));
            arr(k)=[];
            [arr,arr_resort]=sort([arr lab_leav(ar_ind(k))],'ascend');
            a=ar_ind(k);
            ar_ind(k)=[];
            ar_ind=[ar_ind a];
            ar_ind=ar_ind(arr_resort);
            reexam_ind(a)=1;
        else doc_leav(ar_ind(k))=exam_leav(ar_ind(k));
            k=k+1;
        end
    else 
        if doc_serve<=arr(k)
            doc_leav(ar_ind(k))=arr(k)+exprnd(reexam_mean);
        else doc_leav(ar_ind(k))=doc_serve+exprnd(reexam_mean);
            wtime(ar_ind(k))=wtime(ar_ind(k))+doc_serve-arr(k);
        end
        doc_times(doc_ind)=doc_leav(ar_ind(k));
        k=k+1;
    end
end

%simulate the arrival to emergency room
total_doc_leav=length(doc_leav);
emer_count=0;
for i=1:total_doc_leav
    route_2=binornd(1,0.4);
    if route_2==1
        emer_count=emer_count+1;
        emer_arr(emer_count)=doc_leav(i);
        fwtime(emer_count)=wtime(i);
    end
end
[emer_arr,emer_resort]=sort(emer_arr,'ascend');
fwtime=fwtime(emer_resort);

%simulate the emergency room process
nurse_times=zeros(num_nurse,1);
dismiss=zeros(1,emer_count);
for k=1:emer_count
    [nurse_serve,nurse_ind]=min(nurse_times);
    if nurse_serve<=emer_arr(k)
        dismiss(k)=emer_arr(k)+exprnd(emer_mean);
    else dismiss(k)=nurse_serve+exprnd(emer_mean);
        fwtime(k)=fwtime(k)+nurse_serve-emer_arr(k);
    end
    nurse_times(nurse_ind)=dismiss(k);
end
truncation=find(dismiss>96&dismiss<upper_limit);
fwtime=fwtime(truncation);
measure(l)=mean(fwtime);
end
end


            
            
        
    
    