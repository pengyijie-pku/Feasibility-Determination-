function r=trianrnd(a,b,c,n)
r=b+sqrt(rand(n,1)).*(a-b+rand(n,1)*(c-a));